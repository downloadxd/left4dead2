Left 4 Downtown 2 Sourcemod Extension
---------- version 0.5.4.2

Installation:
* Extract files into /left4dead2/addons/sourcemod/

----------

CVARS:

* l4d_maxplayers - (default: -1) Override the in-game max player count (up to 18) (Only in playerslots builds as of 0.5.3)
* left4downtown_version - current version number
----------

NOTES:

* l4d_maxplayers is restricted to <= maxplayers as set on command line. If you cannot go above 8, buy more slots from your GSP. (Only applies to playerslots builds)